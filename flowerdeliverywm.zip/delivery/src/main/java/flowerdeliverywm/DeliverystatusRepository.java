package flowerdeliverywm;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DeliverystatusRepository extends CrudRepository<Deliverystatus, Long> {


}